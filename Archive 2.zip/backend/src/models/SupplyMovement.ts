import { Schema, model, Document } from 'mongoose';

export interface ISupplyMovement extends Document {
  id: string;
  supplyId: string;
  branchId: string;
  type: 'IN' | 'OUT' | 'TRANSFER' | 'ADJUSTMENT';
  quantity: number;
  date: string;
  referenceType?: 'PURCHASE' | 'PRODUCTION' | 'INVENTORY_ADJUSTMENT' | 'TRANSFER';
  referenceId?: string;
  notes?: string;
  createdBy: string;
}

const SupplyMovementSchema = new Schema({
  id: { type: String, required: true, unique: true },
  supplyId: { type: String, required: true },
  branchId: { type: String, required: true },
  type: { type: String, enum: ['IN', 'OUT', 'TRANSFER', 'ADJUSTMENT'], required: true },
  quantity: { type: Number, required: true },
  date: { type: String, required: true },
  referenceType: { type: String, enum: ['PURCHASE', 'PRODUCTION', 'INVENTORY_ADJUSTMENT', 'TRANSFER'] },
  referenceId: { type: String },
  notes: { type: String },
  createdBy: { type: String, required: true }
}, {
  timestamps: true
});

export default model<ISupplyMovement>('SupplyMovement', SupplyMovementSchema);