import mongoose from "mongoose"

const branchSchema = new mongoose.Schema(
  {
    _id: { type: Number, required: true },
    name: { type: String, required: true },
    code: { type: String, required: true, unique: true },
    address: { type: String },
    city: { type: String },
    phone: { type: String },
    email: { type: String },
    managerId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    status: { type: String, enum: ["active", "inactive", "closed"], default: "active" },
    businessType: { type: String, enum: ["retail", "wholesale", "manufacturing", "warehouse", "office"] },
  },
  { timestamps: true },
)

// Add a pre-save hook to ensure _id is handled correctly
branchSchema.pre('save', function(next) {
  // If _id is not a number, we should handle this case
  if (this._id && typeof this._id !== 'number') {
    // If it's an ObjectId, convert to string and then to number if possible
    if ((this._id as any) instanceof mongoose.Types.ObjectId) {
      // Try to convert ObjectId to number, fallback to generating a new number ID
      try {
        const idString = (this._id as any).toString();
        const numericPart = idString.match(/\d+/);
        this._id = numericPart ? parseInt(numericPart[0]) : Math.floor(Math.random() * 1000000) + 1;
      } catch (e) {
        // Fallback to random number if conversion fails
        this._id = Math.floor(Math.random() * 1000000) + 1;
      }
    } else {
      // For other types, try parsing or generate new number
      const parsed = parseInt(this._id as any);
      this._id = isNaN(parsed) ? Math.floor(Math.random() * 1000000) + 1 : parsed;
    }
  }
  next();
});

export default mongoose.model("Branch", branchSchema, "branches")