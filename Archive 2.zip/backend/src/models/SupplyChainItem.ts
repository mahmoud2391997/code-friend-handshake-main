import { Schema, model, Document } from 'mongoose';

export interface ISupplyChainItem extends Document {
  id: number;
  sku?: string;
  gtin?: string;
  batchNumber?: string;
  serialNumber?: string;
  productName: string;
  quantity: number;
  unit?: string;
  manufacturer?: string;
  originCountry?: string;
  manufactureDate?: string;
  expiryDate?: string;
  currentStatus?: string;
  transportMode?: string;
}

const SupplyChainItemSchema = new Schema({
  id: { type: Number, required: true, unique: true },
  sku: { type: String },
  gtin: { type: String },
  batchNumber: { type: String },
  serialNumber: { type: String },
  productName: { type: String, required: true },
  quantity: { type: Number, required: true },
  unit: { type: String },
  manufacturer: { type: String },
  originCountry: { type: String },
  manufactureDate: { type: String },
  expiryDate: { type: String },
  currentStatus: { type: String },
  transportMode: { type: String }
}, {
  timestamps: true
});

export default model<ISupplyChainItem>('SupplyChainItem', SupplyChainItemSchema);