import { Schema, model, Document } from 'mongoose';

export interface IStockMovement extends Document {
  id: number;
  inventory_item_id: number;
  item_name: string;
  movement_type: "in" | "out" | "adjustment";
  quantity: number;
  reference_type: string;
  notes?: string;
  created_at: string;
}

const StockMovementSchema = new Schema({
  id: { type: Number, required: true, unique: true },
  inventory_item_id: { type: Number, required: true },
  item_name: { type: String, required: true },
  movement_type: { type: String, enum: ["in", "out", "adjustment"], required: true },
  quantity: { type: Number, required: true },
  reference_type: { type: String, required: true },
  notes: { type: String },
  created_at: { type: String, required: true }
}, {
  timestamps: true
});

export default model<IStockMovement>('StockMovement', StockMovementSchema);