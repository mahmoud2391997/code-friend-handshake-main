import express from 'express';
import {
  getSupplyMovements,
  getSupplyMovementById,
  createSupplyMovement,
  updateSupplyMovement,
  deleteSupplyMovement
} from '../controllers/supplyMovementController';

const router = express.Router();

router.get('/', getSupplyMovements);
router.get('/:id', getSupplyMovementById);
router.post('/', createSupplyMovement);
router.put('/:id', updateSupplyMovement);
router.delete('/:id', deleteSupplyMovement);

export default router;