import express from 'express';
import {
  getSupplyChainItems,
  getSupplyChainItemById,
  createSupplyChainItem,
  updateSupplyChainItem,
  deleteSupplyChainItem
} from '../controllers/supplyChainController';

const router = express.Router();

router.get('/', getSupplyChainItems);
router.get('/:id', getSupplyChainItemById);
router.post('/', createSupplyChainItem);
router.put('/:id', updateSupplyChainItem);
router.delete('/:id', deleteSupplyChainItem);

export default router;