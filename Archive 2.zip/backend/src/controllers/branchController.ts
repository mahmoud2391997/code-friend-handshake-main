import { Request, Response } from 'express';
import Branch from '../models/Branch';

// Get all branches
export const getBranches = async (req: Request, res: Response) => {
  try {
    const branches = await Branch.find().populate('managerId');
    res.status(200).json(branches);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching branches', error });
  }
};

// Get branch by ID
export const getBranchById = async (req: Request, res: Response) => {
  try {
    const branch = await Branch.findOne({ _id: req.params.id }).populate('managerId');
    if (!branch) {
      return res.status(404).json({ message: 'Branch not found' });
    }
    res.status(200).json(branch);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching branch', error });
  }
};

// Create new branch
export const createBranch = async (req: Request, res: Response) => {
  try {
    const branch = new Branch(req.body);
    await branch.save();
    res.status(201).json(branch);
  } catch (error) {
    res.status(500).json({ message: 'Error creating branch', error });
  }
};

// Update branch
export const updateBranch = async (req: Request, res: Response) => {
  try {
    const branch = await Branch.findOneAndUpdate(
      { _id: req.params.id },
      req.body,
      { new: true }
    ).populate('managerId');
    if (!branch) {
      return res.status(404).json({ message: 'Branch not found' });
    }
    res.status(200).json(branch);
  } catch (error) {
    res.status(500).json({ message: 'Error updating branch', error });
  }
};

// Delete branch
export const deleteBranch = async (req: Request, res: Response) => {
  try {
    const branch = await Branch.findOneAndDelete({ _id: req.params.id });
    if (!branch) {
      return res.status(404).json({ message: 'Branch not found' });
    }
    res.status(200).json({ message: 'Branch deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting branch', error });
  }
};