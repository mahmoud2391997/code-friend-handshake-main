import { Request, Response } from 'express';
import InventoryItem from '../models/InventoryItem';

// Get all inventory items
export const getInventoryItems = async (req: Request, res: Response) => {
  try {
    const items = await InventoryItem.find();
    res.status(200).json(items);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching inventory items', error });
  }
};

// Get inventory item by ID
export const getInventoryItemById = async (req: Request, res: Response) => {
  try {
    const item = await InventoryItem.findOne({ id: req.params.id });
    if (!item) {
      return res.status(404).json({ message: 'Inventory item not found' });
    }
    res.status(200).json(item);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching inventory item', error });
  }
};

// Create new inventory item
export const createInventoryItem = async (req: Request, res: Response) => {
  try {
    // Auto-generate ID if not provided
    let nextId = 1;
    if (!req.body.id) {
      const lastItem = await InventoryItem.findOne().sort({ id: -1 }).exec();
      nextId = lastItem && typeof lastItem.id === 'number' ? lastItem.id + 1 : 1;
    } else {
      nextId = req.body.id;
    }
    
    // Set default values for required fields
    const itemData = {
      ...req.body,
      id: nextId,
      type: req.body.category || req.body.type || 'general',
      locked: req.body.locked || false,
      branchId: req.body.branchId || `branch_${nextId}`,
      productId: req.body.productId || `product_${nextId}`
    };
    
    const item = new InventoryItem(itemData);
    await item.save();
    res.status(201).json(item);
  } catch (error) {
    console.error('Create inventory item error:', error);
    res.status(500).json({ message: 'Error creating inventory item', error });
  }
};

// Update inventory item
export const updateInventoryItem = async (req: Request, res: Response) => {
  try {
    const item = await InventoryItem.findOneAndUpdate(
      { id: req.params.id },
      req.body,
      { new: true }
    );
    if (!item) {
      return res.status(404).json({ message: 'Inventory item not found' });
    }
    res.status(200).json(item);
  } catch (error) {
    res.status(500).json({ message: 'Error updating inventory item', error });
  }
};

// Delete inventory item
export const deleteInventoryItem = async (req: Request, res: Response) => {
  try {
    const item = await InventoryItem.findOneAndDelete({ id: req.params.id });
    if (!item) {
      return res.status(404).json({ message: 'Inventory item not found' });
    }
    res.status(200).json({ message: 'Inventory item deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting inventory item', error });
  }
};