// src/store/slices/branchInventorySlice.ts
import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { API_BASE_URL } from '../../config/api';

export interface BranchInvItem {
  id: string;
  branchId: number;
  productId: number;
  quantity: number;
  minStock: number;
  lotNumber?: string;
  expiryDate?: string;
  createdAt?: string;
  updatedAt?: string;
}

interface Pagination {
  currentPage: number;
  totalPages: number;
  totalItems: number;
  itemsPerPage: number;
  hasNextPage: boolean;
  hasPrevPage: boolean;
}

interface BranchInventoryState {
  items: BranchInvItem[];
  loading: boolean;
  error: string | null;
  pagination: Pagination | null;
}

const initialState: BranchInventoryState = {
  items: [],
  loading: false,
  error: null,
  pagination: null,
};

export const fetchBranchInventory = createAsyncThunk(
  'branchInventory/fetch',
  async (params: {
    branchId?: number;
    productId?: number;
    page?: number;
    limit?: number;
  } = {}, { rejectWithValue }) => {
    const qp = new URLSearchParams();
    if (params.branchId) qp.append('branchId', String(params.branchId));
    if (params.productId) qp.append('productId', String(params.productId));
    if (params.page) qp.append('page', String(params.page));
    if (params.limit) qp.append('limit', String(params.limit));

    try {
      const res = await fetch(`${API_BASE_URL}/branch-inventory?${qp.toString()}`);
      if (!res.ok) {
        const txt = await res.text();
        throw new Error(txt || 'Failed to fetch branch inventory');
      }
      const json = await res.json();
      const data: BranchInvItem[] = (json.data ?? []).map((d: any) => ({
        id: d._id,
        branchId: d.branchId,
        productId: d.productId,
        quantity: d.quantity,
        minStock: d.minStock,
        lotNumber: d.lotNumber,
        expiryDate: d.expiryDate,
        createdAt: d.createdAt,
        updatedAt: d.updatedAt,
      }));
      return { data, pagination: json.pagination as Pagination };
    } catch (err: any) {
      return rejectWithValue(err.message || 'Network error');
    }
  }
);

export const createBranchInvItem = createAsyncThunk(
  'branchInventory/create',
  async (payload: Omit<BranchInvItem, 'id'>, { rejectWithValue }) => {
    try {
      const res = await fetch(`${API_BASE_URL}/branch-inventory`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const txt = await res.text();
        throw new Error(txt || 'Failed to create branch inventory record');
      }
      const json = await res.json();
      return { id: json.data._id, ...json.data } as BranchInvItem;
    } catch (err: any) {
      return rejectWithValue(err.message || 'Network error');
    }
  }
);

export const updateBranchInvItem = createAsyncThunk(
  'branchInventory/update',
  async (
    payload: {
      branchId: number;
      productId: number;
      lotNumber?: string;
      data: Partial<BranchInvItem>;
    },
    { rejectWithValue }
  ) => {
    try {
      const body = {
        branchId: payload.branchId,
        productId: payload.productId,
        lotNumber: payload.lotNumber,
        ...payload.data,
      };
      const res = await fetch(`${API_BASE_URL}/branch-inventory`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const txt = await res.text();
        throw new Error(txt || 'Failed to update branch inventory record');
      }
      const json = await res.json();
      return { id: json.data._id, ...json.data } as BranchInvItem;
    } catch (err: any) {
      return rejectWithValue(err.message || 'Network error');
    }
  }
);

export const deleteBranchInvItem = createAsyncThunk(
  'branchInventory/delete',
  async (
    payload: { branchId: number; productId: number; lotNumber?: string },
    { rejectWithValue }
  ) => {
    try {
      const res = await fetch(`${API_BASE_URL}/branch-inventory`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const txt = await res.text();
        throw new Error(txt || 'Failed to delete branch inventory record');
      }
      return payload;
    } catch (err: any) {
      return rejectWithValue(err.message || 'Network error');
    }
  }
);

const branchInventorySlice = createSlice({
  name: 'branchInventory',
  initialState,
  reducers: {
    clearBranchInventoryError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    // Fetch
    builder
      .addCase(fetchBranchInventory.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchBranchInventory.fulfilled, (state, action: PayloadAction<{ data: BranchInvItem[]; pagination: Pagination }>) => {
        state.loading = false;
        state.items = action.payload.data;
        state.pagination = action.payload.pagination;
      })
      .addCase(fetchBranchInventory.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });

    // Create
    builder
      .addCase(createBranchInvItem.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createBranchInvItem.fulfilled, (state, action: PayloadAction<BranchInvItem>) => {
        state.loading = false;
        state.items.unshift(action.payload);
      })
      .addCase(createBranchInvItem.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });

    // Update
    builder.addCase(updateBranchInvItem.fulfilled, (state, action: PayloadAction<BranchInvItem>) => {
      const idx = state.items.findIndex((i) => i.id === action.payload.id);
      if (idx !== -1) state.items[idx] = action.payload;
    });

    // Delete
    builder.addCase(deleteBranchInvItem.fulfilled, () => {
      // No ID returned → UI should refetch
    });
  },
});

export const { clearBranchInventoryError } = branchInventorySlice.actions;
export default branchInventorySlice.reducer;