import { API_BASE_URL } from '../../config/api';
import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';

// Define the SupplyMovement type
interface SupplyMovement {
  id: number;
  productId: string;
  movementType: 'IN' | 'OUT';
  quantity: number;
  fromBranch?: string;
  toBranch?: string;
  branchId?: string;
  date: string;
  notes?: string;
  reason?: string;
  createdBy?: number;
  createdAt?: string;
  _id?: string;
}

interface SupplyMovementsState {
  movements: SupplyMovement[];
  loading: boolean;
  error: string | null;
}

const initialState: SupplyMovementsState = {
  movements: [],
  loading: false,
  error: null,
};

// Define API base URL

// Async thunk to fetch supply movements
export const fetchSupplyMovements = createAsyncThunk(
  'supplyMovements/fetchSupplyMovements',
  async (_, { rejectWithValue }) => {
    try {
      // Fixed endpoint to match the actual backend route for supply movements
      const response = await fetch(`${API_BASE_URL}/supply-movements`);
      if (!response.ok) {
        console.log(response);
        
        throw new Error('Failed to fetch supply movements');
      }
      const data = await response.json();
      console.log("Asd",data);
      
      
      // Map the data to match our SupplyMovement interface
      const mappedData = data.map((m: any) => ({
        ...m,
        id: m._id, // Keep the original _id as id
        productId: m.productId || m.supplyId,
        movementType: m.movementType || m.type,
        branchId: m.toBranch || m.fromBranch || m.branchId,
        date: m.createdAt || m.date,
        reason: m.notes || m.reason
      }));
      
      return mappedData;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Async thunk to create a new supply movement (IN)
export const createSupplyInMovement = createAsyncThunk(
  'supplyMovements/createSupplyInMovement',
  async (movementData: { supplyId: string; branchId: string; quantity: number; notes?: string; createdBy: number }, { rejectWithValue }) => {
    try {
      // Fixed endpoint URL to match backend route
      const response = await fetch(`/api/supply-movements/receive/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(movementData),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to create supply movement');
      }
      
      const newMovement = await response.json();
      return newMovement;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Async thunk to create a new supply movement (OUT)
export const createSupplyOutMovement = createAsyncThunk(
  'supplyMovements/createSupplyOutMovement',
  async (movementData: { supplyId: string; branchId: string; quantity: number; notes?: string; createdBy: number }, { rejectWithValue }) => {
    try {
      // Fixed endpoint URL to match backend route
      const response = await fetch(`/api/supply-movements/issue/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(movementData),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to create supply movement');
      }
      
      const newMovement = await response.json();
      return newMovement;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Async thunk to import supply movements from Excel
export const importSupplyMovements = createAsyncThunk(
  'supplyMovements/importSupplyMovements',
  async (movementsData: Array<{ 
    supplyId: string; 
    branchId: string; 
    quantity: number; 
    movementType: 'IN' | 'OUT'; 
    notes?: string; 
    createdBy: number;
    date?: string;
  }>, { rejectWithValue }) => {
    try {
      const results = [];
      
      // Process each movement in the imported data
      for (const movement of movementsData) {
        let response;
        if (movement.movementType === 'IN') {
          response = await fetch(`/api/supply-movements/receive/`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              supplyId: movement.supplyId,
              branchId: movement.branchId,
              quantity: movement.quantity,
              notes: movement.notes,
              createdBy: movement.createdBy
            }),
          });
        } else {
          response = await fetch(`/api/supply-movements/issue/`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              supplyId: movement.supplyId,
              branchId: movement.branchId,
              quantity: movement.quantity,
              notes: movement.notes,
              createdBy: movement.createdBy
            }),
          });
        }
        
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || `Failed to create ${movement.movementType} movement`);
        }
        
        const newMovement = await response.json();
        results.push(newMovement);
      }
      
      return results;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Async thunk to delete a supply movement
export const deleteSupplyMovement = createAsyncThunk(
  'supplyMovements/deleteSupplyMovement',
  async (id: string, { rejectWithValue }) => { // Changed id type to string
    try {
      // Fixed endpoint URL to match backend route
      const response = await fetch(`/api/supply-movements/${id}/`, { // Use string id directly
        method: 'DELETE',
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to delete supply movement');
      }
      
      return id; // Return the string id
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

const supplyMovementsSlice = createSlice({
  name: 'supplyMovements',
  initialState,
  reducers: {
    clearMovements: (state) => {
      state.movements = [];
      state.error = null;
    },
    addMovement: (state, action: PayloadAction<SupplyMovement>) => {
      state.movements.push(action.payload);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchSupplyMovements.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchSupplyMovements.fulfilled, (state, action: PayloadAction<SupplyMovement[]>) => {
        state.loading = false;
        state.movements = action.payload;
      })
      .addCase(fetchSupplyMovements.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(createSupplyInMovement.fulfilled, (state, action: PayloadAction<SupplyMovement>) => {
        state.movements.push(action.payload);
      })
      .addCase(createSupplyOutMovement.fulfilled, (state, action: PayloadAction<SupplyMovement>) => {
        state.movements.push(action.payload);
      })
      .addCase(importSupplyMovements.fulfilled, (state, action: PayloadAction<SupplyMovement[]>) => {
        state.movements.push(...action.payload);
      })
      .addCase(deleteSupplyMovement.fulfilled, (state, action: PayloadAction<string>) => { // Updated type
        state.movements = state.movements.filter(movement => movement._id !== action.payload); // Compare with _id
      });
  },
});

export const { clearMovements, addMovement } = supplyMovementsSlice.actions;
export default supplyMovementsSlice.reducer;