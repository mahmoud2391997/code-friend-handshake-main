import { createSlice, createAsyncThunk, PayloadAction } from '@reduxjs/toolkit';
import { ManufacturingOrder } from '../../../types';
import { API_BASE_URL } from '../../config/api';

// Define the state interface
interface ManufacturingOrdersState {
  orders: ManufacturingOrder[];
  loading: boolean;
  error: string | null;
}

// Define the initial state
const initialState: ManufacturingOrdersState = {
  orders: [],
  loading: false,
  error: null,
};

// Async thunk to fetch all manufacturing orders
export const fetchManufacturingOrders = createAsyncThunk<
  ManufacturingOrder[],
  void,
  { rejectValue: string }
>('manufacturingOrders/fetchManufacturingOrders', async (_, { rejectWithValue }) => {
  try {
    const response = await fetch(`${API_BASE_URL}/manufacturing-orders`);
    if (!response.ok) {
      const errorData = await response.json();
      return rejectWithValue(errorData.message || 'Failed to fetch manufacturing orders.');
    }
    const data: ManufacturingOrder[] = await response.json();
    return data;
  } catch (error: any) {
    return rejectWithValue(error.message || 'Network error.');
  }
});

// Async thunk to create a new manufacturing order
export const createManufacturingOrder = createAsyncThunk<
  ManufacturingOrder,
  ManufacturingOrder,
  { rejectValue: string }
>('manufacturingOrders/createManufacturingOrder', async (newOrder, { rejectWithValue }) => {
  try {
    const response = await fetch(`${API_BASE_URL}/api/manufacturing-orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(newOrder),
    });
    if (!response.ok) {
      const errorData = await response.json();
      return rejectWithValue(errorData.message || 'Failed to create manufacturing order.');
    }
    const data: ManufacturingOrder = await response.json();
    return data;
  } catch (error: any) {
    return rejectWithValue(error.message || 'Network error.');
  }
});

// Async thunk to update an existing manufacturing order
export const updateManufacturingOrder = createAsyncThunk<
  ManufacturingOrder,
  ManufacturingOrder,
  { rejectValue: string }
>('manufacturingOrders/updateManufacturingOrder', async (updatedOrder, { rejectWithValue }) => {
  try {
    const response = await fetch(`${API_BASE_URL}/api/manufacturing-orders/${updatedOrder.id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(updatedOrder),
    });
    if (!response.ok) {
      const errorData = await response.json();
      return rejectWithValue(errorData.message || 'Failed to update manufacturing order.');
    }
    const data: ManufacturingOrder = await response.json();
    return data;
  } catch (error: any) {
    return rejectWithValue(error.message || 'Network error.');
  }
});

// Async thunk to delete a manufacturing order
export const deleteManufacturingOrder = createAsyncThunk<
  string, // Return the ID of the deleted order
  string, // Pass the ID of the order to delete
  { rejectValue: string }
>('manufacturingOrders/deleteManufacturingOrder', async (orderId, { rejectWithValue }) => {
  try {
    const response = await fetch(`${API_BASE_URL}/api/manufacturing-orders/${orderId}`, {
      method: 'DELETE',
    });
    if (!response.ok) {
      const errorData = await response.json();
      return rejectWithValue(errorData.message || 'Failed to delete manufacturing order.');
    }
    return orderId; // Return the ID to remove it from state
  } catch (error: any) {
    return rejectWithValue(error.message || 'Network error.');
  }
});

// Create the Redux slice
const manufacturingOrdersSlice = createSlice({
  name: 'manufacturingOrders',
  initialState,
  reducers: {
    // Synchronous reducers can be added here if needed
  },
  extraReducers: (builder) => {
    builder
      // Fetch Manufacturing Orders
      .addCase(fetchManufacturingOrders.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchManufacturingOrders.fulfilled, (state, action: PayloadAction<ManufacturingOrder[]>) => {
        state.loading = false;
        state.orders = action.payload;
      })
      .addCase(fetchManufacturingOrders.rejected, (state, action: PayloadAction<string | undefined>) => {
        state.loading = false;
        state.error = action.payload || 'Failed to fetch manufacturing orders.';
      })
      // Create Manufacturing Order
      .addCase(createManufacturingOrder.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createManufacturingOrder.fulfilled, (state, action: PayloadAction<ManufacturingOrder>) => {
        state.loading = false;
        state.orders.push(action.payload);
      })
      .addCase(createManufacturingOrder.rejected, (state, action: PayloadAction<string | undefined>) => {
        state.loading = false;
        state.error = action.payload || 'Failed to create manufacturing order.';
      })
      // Update Manufacturing Order
      .addCase(updateManufacturingOrder.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateManufacturingOrder.fulfilled, (state, action: PayloadAction<ManufacturingOrder>) => {
        state.loading = false;
        const index = state.orders.findIndex((order) => order.id === action.payload.id);
        if (index !== -1) {
          state.orders[index] = action.payload;
        }
      })
      .addCase(updateManufacturingOrder.rejected, (state, action: PayloadAction<string | undefined>) => {
        state.loading = false;
        state.error = action.payload || 'Failed to update manufacturing order.';
      })
      // Delete Manufacturing Order
      .addCase(deleteManufacturingOrder.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteManufacturingOrder.fulfilled, (state, action: PayloadAction<string>) => {
        state.loading = false;
        state.orders = state.orders.filter((order) => order.id !== action.payload);
      })
      .addCase(deleteManufacturingOrder.rejected, (state, action: PayloadAction<string | undefined>) => {
        state.loading = false;
        state.error = action.payload || 'Failed to delete manufacturing order.';
      });
  },
});

export default manufacturingOrdersSlice.reducer;