/// <reference types="vite/client" />

export const API_BASE_URL = 'http://localhost:4100/api';

export const API_ENDPOINTS = {
  AUTH_LOGIN: `/auth/login`,
  BRANCHES: `/branches`,
  MOVEMENTS: `/supply-movements`,
  ORDERS: `/orders`,
  SUPPLY_CHAIN: `/supplychains`,
  SUPPLY_INVENTORY: `/inventoryitems`,
  MANUFACTURING_ORDERS: `/manufacturing-orders`,
} as const;

export const setupApiErrorLogging = (store: any) => {
  const originalFetch = globalThis.fetch;
  globalThis.fetch = async (input: RequestInfo | URL, init?: RequestInit): Promise<Response> => {
    try {
      const response = await originalFetch(input, init);
      if (!response.ok) {
        console.error('[API NETWORK ERROR]', {
            url: response.url,
            method: init?.method || 'GET',
            status: response.status,
            statusText: response.statusText,
        });
      }
      return response;
    } catch (error) {
      console.error('[API FETCH THREW ERROR]', { error });
      throw error;
    }
  };
};