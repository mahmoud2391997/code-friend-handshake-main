// src/pages/SupplyMovementsPage.tsx
import React, { useEffect, useMemo, useState, useContext } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { AuthContext } from '../../App';
import { FilterIcon, PlusIcon, RefreshIcon } from '../../components/Icon';
import { useToasts } from '../../components/Toast';
import {
  fetchSupplyInventory,
  createSupplyMovement,
  deleteMovement,
} from '../../src/store/slices/supplyInventorySlice';
import { fetchSupplyChainItems } from '../../src/store/slices/supplyChainItemsSlice';
import { fetchBranches } from '../../src/store/slices/branchSlice';
import { 
  fetchSupplyMovements as fetchSupplyMovementsAction,
  importSupplyMovements as importSupplyMovementsAction
} from '../../src/store/slices/supplyMovementsSlice';
import type { RootState, AppDispatch } from '../../src/store';
import SupplyMovementModal from '../../components/SupplyMovementModal';
import { SupplyChainItem, SupplyMovement } from '../../types';
import { Permission } from '../../types';

type MovementDisplay = {
  id: string;
  supplyName: string;
  branchName: string;
  type: 'IN' | 'OUT' | 'TRANSFER' | 'ADJUSTMENT';
  quantity: number;
  date: string;
  reason?: string;
};

const SupplyMovementsPage: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { user } = useContext(AuthContext);
  const { addToast } = useToasts();

  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [filterText, setFilterText] = useState('');
  const [selectedBranchId, setSelectedBranchId] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<'ALL' | 'IN' | 'OUT' | 'TRANSFER' | 'ADJUSTMENT'>('ALL');
  const [modalOpen, setModalOpen] = useState(false);
  const [importFile, setImportFile] = useState<File | null>(null);

  // Redux state
  const movements = useSelector((state: RootState) => state.supplyMovements.movements || []);
  const movementsLoading = useSelector((state: RootState) => state.supplyMovements.loading);
  const movementsError = useSelector((state: RootState) => state.supplyMovements.error);

  const inventoryLoading = useSelector((state: RootState) => state.supplyInventory.loading);
  const inventoryError = useSelector((state: RootState) => state.supplyInventory.error);

  const supplies = useSelector((state: RootState) => state.supplyChainItems.items) as SupplyChainItem[];
  const allBranches = useSelector((state: RootState) => state.branches.branches) as any[];

  const branchLoading = useSelector((state: RootState) => state.branches.loading);
  const branchError = useSelector((state: RootState) => state.branches.error);

  // Responsive
  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Safe ID
  const getId = (item: any): string => {
    const id = item?._id || item?.id;
    if (!id) return '';
    return typeof id === 'object' && id.toString ? id.toString() : String(id);
  };

  // Valid items
  const validSupplies = useMemo(() => 
    supplies.filter(s => getId(s) && s.productName), [supplies]
  );

  const validBranches = useMemo(() => 
    allBranches.filter(b => getId(b) && b.name), [allBranches]
  );

  // Lookups
  const supplyLookup = useMemo(() => {
    const map = new Map<string, string>();
    validSupplies.forEach(s => map.set(getId(s), s.productName));
    return map;
  }, [validSupplies]);

  const branchLookup = useMemo(() => {
    const map = new Map<string, string>();
    validBranches.forEach(b => map.set(getId(b), b.name));
    return map;
  }, [validBranches]);

  // Display movements
  const displayMovements = useMemo<MovementDisplay[]>(() => {
    return movements
      .filter((m: any) => m && (m.type || m.movementType))
      .map((m: any): MovementDisplay => {
        const id = getId(m);
        const type = (m.type || m.movementType) as MovementDisplay['type'];
        const supplyId = getId({ _id: m.supplyId || m.productId });
        const branchId = getId({ _id: m.branchId || m.toBranch });

        return {
          id,
          supplyName: supplyLookup.get(supplyId) || 'غير معروف',
          branchName: branchLookup.get(branchId) || 'غير معروف',
          type,
          quantity: Number(m.quantity) || 0,
          date: new Date(m.date || m.createdAt || Date.now()).toLocaleString('ar-EG', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
          }),
          reason: m.notes || m.reason,
        };
      });
  }, [movements, supplyLookup, branchLookup]);

  // Filter
  const filteredMovements = useMemo(() => {
    return displayMovements.filter(m => {
      const matchesText = !filterText ||
        m.supplyName.toLowerCase().includes(filterText.toLowerCase()) ||
        (m.reason?.toLowerCase().includes(filterText.toLowerCase()));

      const matchesBranch = !selectedBranchId || m.branchName === branchLookup.get(selectedBranchId);
      const matchesType = selectedType === 'ALL' || m.type === selectedType;

      return matchesText && matchesBranch && matchesType;
    });
  }, [displayMovements, filterText, selectedBranchId, selectedType, branchLookup]);

  // Permissions
  const hasPermission = (perm: 'create' | 'read' | 'delete'): boolean => {
    if (!user?.permissions) return false;
    return user.permissions.includes(`movements:${perm}` as Permission);
  };

  // Handlers
  const handleDelete = (id: string) => {
    if (!window.confirm('هل أنت متأكد من حذف هذه الحركة؟')) return;
    dispatch(deleteMovement(id));
    addToast('تم حذف الحركة', 'success');
  };

  const handleSave = async (data: Omit<SupplyMovement, 'id' | 'date'>) => {
    try {
      if (!data.supplyId || !data.branchId) {
        throw new Error('يجب تحديد المادة والفرع');
      }

      const payload = {
        ...data,
        createdBy: user!.id, // Real user ID
      };

      await dispatch(createSupplyMovement(payload)).unwrap();
      addToast('تمت إضافة الحركة بنجاح', 'success');
      setModalOpen(false);
    } catch (err: any) {
      addToast(err?.message || 'فشل في إضافة الحركة', 'error');
    }
  };

  const handleImport = async () => {
    if (!importFile) {
      addToast('يرجى اختيار ملف', 'error');
      return;
    }

    try {
      const data = await parseExcelFile(importFile);
      await dispatch(importSupplyMovementsAction(data)).unwrap();
      addToast(`تم استيراد ${data.length} حركة`, 'success');
      setImportFile(null);
    } catch (err: any) {
      addToast(err?.message || 'فشل الاستيراد', 'error');
    }
  };

  const parseExcelFile = async (file: File): Promise<Array<{
    supplyId: string;
    branchId: string;
    movementType: 'IN' | 'OUT';
    quantity: number;
    notes?: string;
    createdBy: number;
  }>> => {
    return new Promise(resolve => {
      setTimeout(() => {
        resolve([
          {
            supplyId: validSupplies[0] ? getId(validSupplies[0]) : '',
            branchId: validBranches[0] ? getId(validBranches[0]) : '',
            movementType: 'IN',
            quantity: 10,
            notes: 'استيراد تجريبي',
            createdBy: parseInt(user!.id) || 0,
          },
        ]);
      }, 500);
    });
  };

  const loading = movementsLoading || inventoryLoading || branchLoading;
  const error = movementsError || inventoryError || branchError;

  useEffect(() => {
    dispatch(fetchSupplyMovementsAction());
    dispatch(fetchSupplyInventory(undefined));
    dispatch(fetchSupplyChainItems({ page: 1, limit: 1000 }));
    dispatch(fetchBranches({ limit: 1000 }));
  }, [dispatch]);

  return (
    <div className="glass-pane" style={{ padding: '1rem 1.5rem' }}>
      {/* Header */}
      <div style={{
        display: 'flex',
        flexDirection: isMobile ? 'column' : 'row',
        justifyContent: 'space-between',
        alignItems: isMobile ? 'stretch' : 'center',
        gap: '1rem',
        marginBottom: '1rem',
      }}>
        <h3 style={{ fontSize: isMobile ? '1.1rem' : '1.35rem', fontWeight: 600 }}>
          حركات المخزون
        </h3>

        {hasPermission('create') && (
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
            <button
              onClick={() => setModalOpen(true)}
              className="btn btn-primary"
              style={{ fontSize: isMobile ? '0.875rem' : '1rem' }}
            >
              <PlusIcon style={{ width: 16, height: 16, marginLeft: '0.25rem' }} />
              {isMobile ? 'إضافة' : 'إضافة حركة'}
            </button>

            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <input
                type="file"
                accept=".xlsx,.xls,.csv"
                onChange={(e) => setImportFile(e.target.files?.[0] || null)}
                style={{ fontSize: '0.875rem' }}
              />
              <button
                onClick={handleImport}
                className="btn btn-secondary"
                style={{ fontSize: '0.875rem' }}
              >
                استيراد
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Filters */}
      <div style={{
        display: 'flex',
        flexDirection: isMobile ? 'column' : 'row',
        gap: '0.5rem',
        marginBottom: '1rem',
        flexWrap: 'wrap',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', flex: 1, minWidth: 200 }}>
          <FilterIcon style={{ width: 16, height: 16, marginLeft: '0.5rem' }} />
          <input
            type="text"
            placeholder="بحث..."
            value={filterText}
            onChange={(e) => setFilterText(e.target.value)}
            style={{
              flex: 1,
              padding: '0.5rem',
              borderRadius: '0.25rem',
              border: '1px solid #e5e7eb',
              fontSize: '0.875rem',
            }}
          />
        </div>

        <select
          value={selectedBranchId || ''}
          onChange={(e) => setSelectedBranchId(e.target.value || null)}
          style={{
            padding: '0.5rem',
            borderRadius: '0.25rem',
            border: '1px solid #e5e7eb',
            minWidth: 140,
            fontSize: '0.875rem',
          }}
        >
          <option value="">جميع الفروع</option>
          {validBranches.map(b => (
            <option key={getId(b)} value={getId(b)}>{b.name}</option>
          ))}
        </select>

        <select
          value={selectedType}
          onChange={(e) => setSelectedType(e.target.value as any)}
          style={{
            padding: '0.5rem',
            borderRadius: '0.25rem',
            border: '1px solid #e5e7eb',
            minWidth: 120,
            fontSize: '0.875rem',
          }}
        >
          <option value="ALL">الكل</option>
          <option value="IN">وارد</option>
          <option value="OUT">صادر</option>
          <option value="TRANSFER">تحويل</option>
          <option value="ADJUSTMENT">تعديل</option>
        </select>

        <button
          onClick={() => {
            setFilterText('');
            setSelectedBranchId(null);
            setSelectedType('ALL');
          }}
          className="btn btn-ghost"
          style={{ fontSize: '0.875rem' }}
        >
          <RefreshIcon style={{ width: 16, height: 16, marginLeft: '0.25rem' }} />
          إعادة
        </button>
      </div>

      {/* Error */}
      {error && (
        <div style={{ marginBottom: '1rem', color: '#ef4444', fontWeight: 500 }}>
          {error}
        </div>
      )}

      {/* Table */}
      {loading ? (
        <div style={{ textAlign: 'center', padding: '2rem' }}>جاري التحميل...</div>
      ) : (
        <div className="table-wrapper" style={{ overflowX: 'auto' }}>
          <table style={{ minWidth: isMobile ? 700 : '100%', width: '100%' }}>
            <thead>
              <tr>
                <th>المادة</th>
                {!isMobile && <th>الفرع</th>}
                <th>النوع</th>
                <th>الكمية</th>
                <th>التاريخ</th>
                {!isMobile && <th>الملاحظات</th>}
                {hasPermission('delete') && <th>إجراءات</th>}
              </tr>
            </thead>
            <tbody>
              {filteredMovements.length > 0 ? (
                filteredMovements.map(m => (
                  <tr key={m.id}>
                    <td>{m.supplyName}</td>
                    {!isMobile && <td>{m.branchName}</td>}
                    <td>
                      <span style={{
                        padding: '0.25rem 0.5rem',
                        borderRadius: '0.25rem',
                        backgroundColor:
                          m.type === 'IN' ? '#d1fae5' :
                          m.type === 'OUT' ? '#fee2e2' :
                          m.type === 'TRANSFER' ? '#dbeafe' : '#f3f4f6',
                        color:
                          m.type === 'IN' ? '#065f46' :
                          m.type === 'OUT' ? '#991b1b' :
                          m.type === 'TRANSFER' ? '#1e40af' : '#374151',
                        fontWeight: 500,
                        fontSize: '0.75rem',
                      }}>
                        {m.type === 'IN' ? 'وارد' : m.type === 'OUT' ? 'صادر' : m.type === 'TRANSFER' ? 'تحويل' : 'تعديل'}
                      </span>
                    </td>
                    <td>{m.quantity}</td>
                    <td style={{ whiteSpace: 'nowrap', fontSize: '0.875rem' }}>{m.date}</td>
                    {!isMobile && <td>{m.reason || '-'}</td>}
                    {hasPermission('delete') && (
                      <td>
                        <button
                          onClick={() => handleDelete(m.id)}
                          className="btn btn-ghost"
                          style={{ color: '#ef4444', fontSize: '0.875rem' }}
                        >
                          حذف
                        </button>
                      </td>
                    )}
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={hasPermission('delete') ? (isMobile ? 5 : 7) : (isMobile ? 4 : 6)}
                      style={{ textAlign: 'center', padding: '2rem', color: '#6b7280' }}>
                    لا توجد حركات
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal */}
      {modalOpen && (
        <SupplyMovementModal
          onClose={() => setModalOpen(false)}
          onSave={handleSave}
          supplies={validSupplies}
          branches={validBranches}
        />
      )}
    </div>
  );
};

export default SupplyMovementsPage;