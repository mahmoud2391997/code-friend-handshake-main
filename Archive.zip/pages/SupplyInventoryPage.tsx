import React from "react";

const SupplyInventoryPage: React.FC = () => {
  return (
    <div>
      <h1>Supply Inventory Page</h1>
      {/* Add your content here */}
    </div>
  );
};

export default SupplyInventoryPage;
