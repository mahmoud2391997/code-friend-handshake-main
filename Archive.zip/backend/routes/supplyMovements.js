import express from "express";
import SupplyMovement from "../models/SupplyMovement.js";
import SupplyInventoryItem from "../models/SupplyInventoryItem.js";

const router = express.Router();

// GET all supply movements
router.get("/", async (req, res) => {
  try {
    // Removed population of branch fields to prevent server crash
    const movements = await SupplyMovement.find().populate("supplyId");
    res.json(movements);
  } catch (err) {
    console.error("Error fetching supply movements:", err);
    res.status(500).json({ message: "Failed to fetch supply movements", error: err.message });
  }
});

// POST a new supply movement (IN)
router.post("/receive", async (req, res) => {
  const { supplyId, branchId, quantity, notes, createdBy } = req.body;
console.log(req.body);

  if (!supplyId || isNaN(branchId) || !quantity) {
    return res.status(400).json({ message: "Missing or invalid required fields for receipt." });
  }

  try {
    // The inventory item model uses 'productId', so we assume the incoming 'supplyId' maps to it.
    await SupplyInventoryItem.findOneAndUpdate(
      { productId: supplyId, branchId },
      { $inc: { quantity } },
      { upsert: true, new: true }
    );

    // Create the supply movement record with corrected field names
    const newMovement = new SupplyMovement({
      supplyId: supplyId,
      type: "IN", // Corrected from movementType
      quantity,
      toBranch: branchId,
      notes,
      createdBy,
    });

    const savedMovement = await newMovement.save();
    res.status(201).json(savedMovement);
  } catch (err) {
    console.log(err);
    
    console.error("Error processing supply receipt:", err);
    res.status(500).json({ message: "Failed to process supply receipt.", error: err.message });
  }
});

// POST a new supply movement (OUT)
router.post("/issue", async (req, res) => {
  const { supplyId, branchId, quantity, notes, createdBy } = req.body;

  if (!supplyId || isNaN(branchId) || !quantity) {
    return res.status(400).json({ message: "Missing or invalid required fields for issue." });
  }

  try {
    const inventoryItem = await SupplyInventoryItem.findOne({ productId: supplyId, branchId });
    if (!inventoryItem || inventoryItem.quantity < quantity) {
      return res.status(400).json({ message: "Insufficient supply in the branch." });
    }

    await SupplyInventoryItem.findOneAndUpdate(
      { productId: supplyId, branchId },
      { $inc: { quantity: -quantity } }
    );

    // Create the supply movement record with corrected field names
    const newMovement = new SupplyMovement({
      supplyId: supplyId,
      type: "OUT", // Corrected from movementType
      quantity,
      fromBranch: branchId,
      notes,
      createdBy,
    });

    const savedMovement = await newMovement.save();
    res.status(201).json(savedMovement);
  } catch (err) {
    // Attempt to roll back the inventory change if movement creation fails
    await SupplyInventoryItem.findOneAndUpdate(
      { productId: supplyId, branchId },
      { $inc: { quantity: quantity } }
    );
    console.error("Error processing supply issue:", err);
    res.status(500).json({ message: "Failed to process supply issue.", error: err.message });
  }
});

// PUT update a supply movement
router.put("/:id", async (req, res) => {
  try {
    const updatedMovement = await SupplyMovement.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!updatedMovement) {
      return res.status(404).json({ message: "Supply movement not found" });
    }
    res.json(updatedMovement);
  } catch (err) {
    console.error("Error updating supply movement:", err);
    res.status(400).json({ message: "Failed to update movement", error: err.message });
  }
});

// DELETE a supply movement
router.delete("/:id", async (req, res) => {
  try {
    const deletedMovement = await SupplyMovement.findByIdAndDelete(req.params.id);
    if (!deletedMovement) {
      return res.status(404).json({ message: "Supply movement not found" });
    }
    res.json({ message: "Supply movement deleted successfully" });
  } catch (err) {
    console.error("Error deleting supply movement:", err);
    res.status(500).json({ message: "Failed to delete movement", error: err.message });
  }
});

export default router;
