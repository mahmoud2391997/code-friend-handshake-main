import express from "express";
import mongoose from "mongoose";
import InventoryItem from "../models/InventoryItem.js";
import { authenticate } from "../middleware/auth.js";

const router = express.Router();

const normalizeBody = (body) => {
  const normalized = { ...body };

  // Aliases -> schema fields
  if (normalized.minStock != null && normalized.minStockLevel == null) {
    normalized.minStockLevel = normalized.minStock;
  }
  if (normalized.lastMovementDate && !normalized.lastRestocked) {
    normalized.lastRestocked = normalized.lastMovementDate;
  }

  // Ensure IDs are strings (ObjectId)
  if (normalized.productId != null)
    normalized.productId = String(normalized.productId);
  if (normalized.branchId != null)
    normalized.branchId = String(normalized.branchId);

  return normalized;
};

const isValidObjectId = (v) =>
  typeof v === "string" && mongoose.isValidObjectId(v);

const sendHandledError = (res, err) => {
  if (
    err instanceof mongoose.Error.CastError ||
    err instanceof mongoose.Error.ValidationError
  ) {
    return res.status(400).json({ success: false, message: err.message });
  }
  return res.status(500).json({ success: false, message: err.message });
};

// ✅ GET all
router.get("/", authenticate, async (req, res) => {
  try {
    const items = await InventoryItem.find().populate("productId branchId");
    res.json({ success: true, data: items });
  } catch (error) {
    sendHandledError(res, error);
  }
});

// ✅ GET by ID
router.get("/:id", authenticate, async (req, res) => {
  try {
    if (!isValidObjectId(req.params.id)) {
      return res.status(400).json({ success: false, message: "Invalid id" });
    }
    const item = await InventoryItem.findById(req.params.id).populate("productId branchId");
    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: item });
  } catch (error) {
    sendHandledError(res, error);
  }
});

// ✅ CREATE
router.post("/", authenticate, async (req, res) => {
  try {
    const body = normalizeBody(req.body);
    if (!isValidObjectId(body.productId) || !isValidObjectId(body.branchId)) {
      return res
        .status(400)
        .json({ success: false, message: "productId and branchId must be valid ObjectIds" });
    }

    const item = await InventoryItem.create(body);
    const populated = await item.populate("productId branchId");
    res.status(201).json({ success: true, data: populated });
  } catch (error) {
    sendHandledError(res, error);
  }
});

// ✅ UPDATE
router.put("/:id", authenticate, async (req, res) => {
  try {
    if (!isValidObjectId(req.params.id)) {
      return res.status(400).json({ success: false, message: "Invalid id" });
    }
    const body = normalizeBody(req.body);
    if (body.productId && !isValidObjectId(body.productId)) {
      return res.status(400).json({ success: false, message: "Invalid productId" });
    }
    if (body.branchId && !isValidObjectId(body.branchId)) {
      return res.status(400).json({ success: false, message: "Invalid branchId" });
    }

    const item = await InventoryItem.findByIdAndUpdate(req.params.id, body, {
      new: true,
      runValidators: true,
    }).populate("productId branchId");

    if (!item) return res.status(404).json({ success: false, message: "Not found" });
    res.json({ success: true, data: item });
  } catch (error) {
    sendHandledError(res, error);
  }
});

// ✅ DELETE
router.delete("/:id", authenticate, async (req, res) => {
  try {
    if (!isValidObjectId(req.params.id)) {
      return res.status(400).json({ success: false, message: "Invalid id" });
    }
    await InventoryItem.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: "Item deleted" });
  } catch (error) {
    sendHandledError(res, error);
  }
});

export default router;
