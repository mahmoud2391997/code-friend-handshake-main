import express from "express";
import SupplyChain from "../models/SupplyChain.js";
import Counter from "../models/Counter.js"; // Import the Counter model
import { authenticate } from "../middleware/auth.js";

const router = express.Router();

// routes/supplychain.js
router.post('/import', async (req, res) => {
  try {
    const items = req.body;
    
    // Assign unique, auto-incrementing IDs to each item
    for (let i = 0; i < items.length; i++) {
      items[i].id = await Counter.getNextSequence('supplyChainId');
    }
    
    const inserted = await SupplyChain.insertMany(items);
    res.json(inserted);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// GET all supply chains with pagination
router.get("/", authenticate, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 50;
    const search = req.query.q || '';
    const skip = (page - 1) * limit;

    // Build search query
    const query = search ? {
      $or: [
        { productName: { $regex: search, $options: 'i' } },
        { sku: { $regex: search, $options: 'i' } },
        { batchNumber: { $regex: search, $options: 'i' } },
        { serialNumber: { $regex: search, $options: 'i' } }
      ]
    } : {};

    const [items, total] = await Promise.all([
      SupplyChain.find(query).skip(skip).limit(limit).sort({ createdAt: -1 }),
      SupplyChain.countDocuments(query)
    ]);

    const totalPages = Math.ceil(total / limit);

    res.json({ 
      success: true, 
      data: items.map(item => item.toObject()), // Convert documents to plain objects
      pagination: {
        currentPage: page,
        totalPages,
        totalItems: total,
        itemsPerPage: limit,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1
      }
    });
  } catch (error) {
    console.error('Supply chain fetch error:', error);
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
});

// GET single supply chain by ID
router.get("/:id", authenticate, async (req, res) => {
  try {
    const chain = await SupplyChain.findById(req.params.id);
    if (!chain) {
      return res.status(404).json({ success: false, message: "Supply chain not found" });
    }
    res.json({ success: true, data: chain.toObject() });
  } catch (error) {
    console.error('Supply chain get error:', error);
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
});

// POST create new supply chain
router.post("/", authenticate, async (req, res) => {
  try {
    // Remove any client-sent _id or other conflicting fields
    const { _id, ...data } = req.body;

    if (!data.productName) {
      return res.status(400).json({ 
        success: false, 
        message: "productName is required" 
      });
    }

    const chain = new SupplyChain(data);
    await chain.save();
    res.status(201).json({ success: true, data: chain.toObject() });
  } catch (error) {
    console.error('Supply chain create error:', error);
    // Use 400 for validation-type errors
    if (error.name === 'ValidationError') {
        return res.status(400).json({ success: false, message: error.message });
    }
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
});

// PUT update supply chain
router.put("/:id", authenticate, async (req, res) => {
  try {
    // Ensure no one is trying to change the _id
    const { _id, ...data } = req.body;
    
    const chain = await SupplyChain.findByIdAndUpdate(
      req.params.id,
      { ...data, updatedAt: new Date() },
      { new: true, runValidators: true }
    );
    
    if (!chain) {
      return res.status(404).json({ success: false, message: "Supply chain not found" });
    }
    
    res.json({ success: true, data: chain.toObject() });
  } catch (error) {
    console.error('Supply chain update error:', error);
    if (error.name === 'ValidationError') {
        return res.status(400).json({ success: false, message: error.message });
    }
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
});

// DELETE supply chain
router.delete("/:id", authenticate, async (req, res) => {
  try {
    const chain = await SupplyChain.findByIdAndDelete(req.params.id);
    if (!chain) {
      return res.status(404).json({ success: false, message: "Supply chain not found" });
    }
    res.json({ success: true, message: "Supply chain deleted successfully" });
  } catch (error) {
    console.error('Supply chain delete error:', error);
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
});

export default router;