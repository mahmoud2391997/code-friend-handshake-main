import express from "express";
import StockMovement from "../models/StockMovement.js";
import InventoryItem from "../models/InventoryItem.js"; // Corrected import

const router = express.Router();

// GET all stock movements
router.get("/", async (req, res) => {
  try {
    const movements = await StockMovement.find().populate("productId fromBranch toBranch");
    console.log(movements);
    
    res.json(movements);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST a new stock transfer
router.post("/transfer", async (req, res) => {
  console.log(req.body);
  
  const { productId, fromBranch, toBranch, quantity, notes } = req.body;

  if (!productId || !fromBranch || !toBranch || !quantity) {
    return res.status(400).json({ message: "Missing required fields for transfer." });
  }

  try {
    // 1. Decrease inventory from the source branch
    const fromInventory = await InventoryItem.findOneAndUpdate(
      { productId, branchId: fromBranch },
      { $inc: { quantity: -quantity } },
      { new: true }
    );

    if (!fromInventory || fromInventory.quantity < 0) {
      // Rollback if stock is insufficient
      await InventoryItem.findOneAndUpdate(
        { productId, branchId: fromBranch },
        { $inc: { quantity: quantity } }
      );
      return res.status(400).json({ message: "Insufficient stock in the source branch." });
    }

    // 2. Increase inventory in the destination branch
    await InventoryItem.findOneAndUpdate(
      { productId, branchId: toBranch },
      { $inc: { quantity: quantity } },
      { upsert: true, new: true } // Creates the inventory item if it doesn't exist
    );

    // 3. Create the stock movement record
    const newMovement = new StockMovement({
      productId,
      movementType: "Transfer",
      quantity,
      fromBranch,
      toBranch,
      notes,
    });

    const savedMovement = await newMovement.save();
    res.status(201).json(savedMovement);
  } catch (err) {
    // Basic error handling; a more robust solution would handle rollbacks
    res.status(500).json({ message: "Failed to process stock transfer.", error: err.message });
  }
});

// POST a new stock receipt (IN movement)
router.post("/receive", async (req, res) => {
  console.log(req.body);
  
  const { supplyId, branchId, type, quantity, notes, createdBy } = req.body;

  if (!supplyId || !branchId || !type || !quantity || type !== 'IN') {
    return res.status(400).json({ message: "Missing required fields for receipt." });
  }

  try {
    // 1. Increase inventory in the destination branch
    await InventoryItem.findOneAndUpdate(
      { productId: supplyId, branchId },
      { $inc: { quantity } },
      { upsert: true, new: true } // Creates the inventory item if it doesn't exist
    );

    // 2. Create the stock movement record
    const newMovement = new StockMovement({
      productId: supplyId,
      movementType: "IN", // This matches the enum value
      quantity,
      toBranch: branchId,
      notes,
      createdBy, // Include the createdBy field
    });

    const savedMovement = await newMovement.save();
    res.status(201).json(savedMovement);
  } catch (err) {
    console.log(err);
    
    res.status(500).json({ message: "Failed to process stock receipt.", error: err.message });
  }
});

export default router;