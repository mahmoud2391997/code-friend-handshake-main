      import mongoose from "mongoose"
      
      const supplyInventoryItemSchema = new mongoose.Schema(
        {
          productId: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
          branchId: { type: Number, ref: "Branch", required: true },
          quantity: { type: Number, required: true, default: 0 },
        },
        { timestamps: true }
      )
      
      // Ensure unique combination of productId and branchId
      supplyInventoryItemSchema.index({ productId: 1, branchId: 1 }, { unique: true })
      
      export default mongoose.model("SupplyInventoryItem", supplyInventoryItemSchema)
