import mongoose from "mongoose"

const stockMovementSchema = new mongoose.Schema(
  {
    productId: { type: mongoose.Schema.Types.ObjectId, ref: "Product", required: true },
    movementType: { type: String, enum: ["Purchase", "Sale", "Adjustment", "Transfer", "IN"], required: true },
    quantity: { type: Number, required: true },
    fromBranch: { type: mongoose.Schema.Types.ObjectId, ref: "Branch" },
    toBranch: { type: mongoose.Schema.Types.ObjectId, ref: "Branch" },
    referenceDocument: String,
    notes: String,
    createdBy: { type: Number, required: false }, // Added to support createdBy field used in receive route
  },
  { timestamps: true },
)

export default mongoose.model("StockMovement", stockMovementSchema)