import mongoose from 'mongoose';

const supplyMovementSchema = new mongoose.Schema(
  {
    projectId: { type: Number, required: false },
    supplyId: { type: mongoose.Schema.Types.ObjectId, ref: 'SupplyChainItem', required: false },
    type: {
      type: String,
      enum: ['IN', 'OUT', 'TRANSFER', 'ADJUSTMENT'],
      required: false,
    },
    quantity: { type: Number, required: true },
    fromBranch: { type: Number, ref: 'Branch' },
    toBranch: { type: Number, ref: 'Branch' },
    notes: { type: String },
    createdBy: { type: String, required: false },
    referenceType: { type: String },
    referenceId: { type: String },
  },
  { timestamps: true }
);

export default mongoose.model('SupplyMovement', supplyMovementSchema);
